MINE Application
================

The **`mine` command-line application** is deprecated since version 1.2.2.
Use `MICtools <https://github.com/minepy/mictools>`_ instead.
